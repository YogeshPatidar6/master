package com.service.service;

import com.service.request.AdminRequest;
import com.service.response.DTO.FarmerUserDTO;

public interface FarmerService {
	Boolean addLists(FarmerUserDTO farmerUserDTO);

}
