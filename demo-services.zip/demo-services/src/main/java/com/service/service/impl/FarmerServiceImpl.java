package com.service.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.service.dao.AdminDAO;
import com.service.dao.FarmerDAO;
import com.service.response.DTO.FarmerUserDTO;
import com.service.service.FarmerService;

public class FarmerServiceImpl implements FarmerService {
	@Autowired
	FarmerDAO farmerDAO;

	@Override
	public Boolean addLists(FarmerUserDTO farmerUserDTO) {
		return FarmerDAO.addFarmeruser(farmerDAO);
	}

}
