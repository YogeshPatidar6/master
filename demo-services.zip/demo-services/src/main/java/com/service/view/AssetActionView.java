package com.service.view;

public interface AssetActionView {

	interface actionListView extends BaseView {
	}

	interface setPointConfigurationView extends BaseView {

	}

}
