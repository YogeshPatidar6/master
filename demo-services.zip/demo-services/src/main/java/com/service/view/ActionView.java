package com.service.view;

public interface ActionView {
	
	interface RootView extends BaseView {
	}

}
