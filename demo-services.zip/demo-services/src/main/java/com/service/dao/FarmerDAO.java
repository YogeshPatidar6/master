package com.service.dao;

import org.springframework.stereotype.Component;

@Component
public interface FarmerDAO {

	static Boolean addFarmeruser(FarmerDAO farmerDAO) {
		// TODO Auto-generated method stub
		return null;
	}



}
