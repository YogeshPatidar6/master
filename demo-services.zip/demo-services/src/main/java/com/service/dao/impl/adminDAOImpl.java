package com.service.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.service.dao.AdminDAO;
import com.service.request.AdminRequest;

@Repository
@Transactional
public class adminDAOImpl implements AdminDAO {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Boolean addAdminuser(AdminRequest adminRequest) {

		Session session = sessionFactory.getCurrentSession();

		String strQuery = "insert into userdetail (userId,name,profile,companyname,experience) values (:userId,:name,\n"
				+ ":profile,:companyname,:experience)";
		try {

			Query query = session.createSQLQuery(strQuery);
			query.setParameter("userId", adminRequest.getUserId());
			query.setParameter("name", adminRequest.getName());
			query.setParameter("profile", adminRequest.getProfile());
			query.setParameter("companyname", adminRequest.getCompanyName());
			query.setParameter("experience", adminRequest.getExperience());

			query.executeUpdate();
			return true;

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("response Body " + e.getMessage());
		} finally {
			session.flush();
			session.clear();
		}
		return false;

	}

	@Override
	public List<AdminRequest> addAdminuser1() {
		Session session = sessionFactory.getCurrentSession();

		try {
			String strQuery = "select * from userdetail";

			Query query = session.createSQLQuery(strQuery);
			query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

			List<Object> rows = query.list();
			List<AdminRequest> adminList = new ArrayList<AdminRequest>();
			for (Object row : rows) {
				AdminRequest notification = new AdminRequest();
				Map<String, Object> map = (Map<String, Object>) row;
				notification.setUserId((Integer) map.get("userId"));
				notification.setName((String) map.get("name"));
				notification.setProfile((String) map.get("profile"));
				notification.setCompanyName((String) map.get("companyname"));
				notification.setExperience((Integer) map.get("experience"));

				adminList.add(notification);
			}
			return adminList;

		} catch (Exception e) {
			e.printStackTrace();
//			logger.error("error occurred" + e.getMessage());
//			logger.debug("DEBUG Error " + e);
			e.printStackTrace();
		} finally {
			session.flush();
			session.clear();
		}
		return null;

	}

	@Override
	public Boolean updatelist(AdminRequest adminRequest) {

		Session session = sessionFactory.getCurrentSession();

		String strQuery = "UPDATE userdetail\n" + "SET name = :name ,\n" + "    profile = :profile,\n"
				+ "    companyName = :companyname,\n" + "    experience = :experience\n" + "WHERE userId =:userId ";

		System.out.println(strQuery);

		try {
			Query query = session.createSQLQuery(strQuery);

			query.setParameter("name", adminRequest.getName());
			query.setParameter("profile", adminRequest.getProfile());
			query.setParameter("companyname", adminRequest.getCompanyName());
			query.setParameter("experience", adminRequest.getExperience());
			query.setParameter("userId", adminRequest.getUserId());

			Integer result = query.executeUpdate();

			System.out.println("result " + result);

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			e.printStackTrace();
		} finally {
			session.flush();
			session.clear();
		}
		return false;
	}

	@Override
	public Boolean deleteUser(Integer userId) {

		Session session = sessionFactory.getCurrentSession();

		try {

			Query query = session.createSQLQuery("DELETE FROM userdetail WHERE userId=:userId");
			query.setParameter("userId", userId);

			query.executeUpdate();
			query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

			return true;
		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {
			session.flush();
			session.clear();
		}
		return false;

	}

}
