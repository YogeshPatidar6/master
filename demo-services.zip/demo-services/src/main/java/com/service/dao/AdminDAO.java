package com.service.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.service.request.AdminRequest;

@Component
public interface AdminDAO  {

	Boolean addAdminuser(AdminRequest adminRequest);

	List<AdminRequest> addAdminuser1();
	
	Boolean updatelist(AdminRequest adminRequest);

	Boolean deleteUser(Integer userId);
}
