package com.service.controller;

import com.service.response.BaseResponse;
import com.service.response.DTO.FarmerUserDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface Farmercontroller {

	BaseResponse creatfarmer(FarmerUserDTO farmerUserDTO, HttpServletRequest request, HttpServletResponse response);

}
