package com.service.view;

public interface AssetActionView {

	public interface getuserlist extends BaseView {
	}
}
