package com.service.view;

public interface BaseView {

}
