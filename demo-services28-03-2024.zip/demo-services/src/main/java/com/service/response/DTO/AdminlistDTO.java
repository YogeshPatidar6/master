package com.service.response.DTO;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonView;
import com.service.view.AssetActionView;

public class AdminlistDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@JsonView(AssetActionView.getuserlist.class)
	private Integer adminId;
	
	@JsonView(AssetActionView.getuserlist.class)
    private String name;
	
	@JsonView(AssetActionView.getuserlist.class)
	private String profile;
	@JsonView(AssetActionView.getuserlist.class)
	private Integer contact_no;
	@JsonView(AssetActionView.getuserlist.class)
	private String address;
	@JsonView(AssetActionView.getuserlist.class)
	private String companyName;
	@JsonView(AssetActionView.getuserlist.class)
	private String experience;

	
	public Integer getAdminId() {
		return adminId;
	}
	public String getName() {
		return name;
	}
	public String getProfile() {
		return profile;
	}
	public Integer getContact_no() {
		return contact_no;
	}
	public String getAddress() {
		return address;
	}
	public String getCompanyName() {
		return companyName;
	}
	public String getExperience() {
		return experience;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public void setContact_no(Integer contact_no) {
		this.contact_no = contact_no;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}

}
